import os
import secrets
import argparse
import sys

# --- Constants & Helpers ---

def create_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)
        print(f"Created directory: {path}")

def write_file(path, content):
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.strip())
    print(f"Created file: {path}")

# --- File Contents ---

SETTINGS_PY = """
import os

BASE_DIR = os.getcwd()
TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'static')

PORT = 8000

# Security
def get_secret_key():
    secret_file = os.path.join(BASE_DIR, '.secret_key')
    try:
        with open(secret_file, 'r') as f:
            return f.read().strip()
    except FileNotFoundError:
        raise RuntimeError("Secret key file not found. Run 'node-web startproject <name>' first.")

SECRET_KEY = get_secret_key()
DEBUG = True
ALLOWED_HOSTS = ['*']

INSTALLED_NODES = [
    'nodes',
]

SECURITY = {
    'RATE_LIMIT_ENABLED': True,
    'RATE_LIMIT_MAX': 50, # requests per window
    'RATE_LIMIT_WINDOW': 60, # seconds
    'CSRF_ENABLED': True,
    'ANTI_SCRAPING_ENABLED': True, # User-Agent checks
    'SCREEN_PROTECTION_ENABLED': True # Black screen on blur/printscreen
}
"""

BASE_NODE_PY = """
class BaseNode:
    \"\"\"
    Base class for all nodes in the framework.
    Implements a doubly linked list structure.
    \"\"\"
    def __init__(self):
        self.next_node = None
        self.prev_node = None

    def connect(self, node):
        \"\"\"
        Connects the next node in the chain.
        Returns the next node to allow chaining: node1.connect(node2).connect(node3)
        \"\"\"
        self.next_node = node
        node.prev_node = self
        return node

    def process(self, data):
        \"\"\"
        Processes data and passes it to the next node.
        Subclasses should override this, perform logic, and then call super().process(new_data)
        \"\"\"
        if self.next_node:
            return self.next_node.process(data)
        return data
"""

SERVER_NODE_PY = """
import http.server
import sys
import os
import importlib
import settings
from nodes.base_node import BaseNode

class ServerNode(BaseNode):
    \"\"\"
    Root Node.
    Configures the server port and initiates the request processing graph.
    Connects to HTTPRequestNode.
    \"\"\"
    def __init__(self, host='127.0.0.1', port=8000):
        super().__init__()
        self.host = host
        self.port = port

    def start_flow(self, handler):
        \"\"\"
        Triggered by FrameworkHandler.
        Passes the raw handler to the next node (HTTPRequestNode).
        \"\"\"
        return self.process(handler)

class FrameworkHandler(http.server.SimpleHTTPRequestHandler):
    \"\"\"
    The actual HTTP Handler that receives requests from socketserver.
    It delegates processing to the ServerNode graph.
    \"\"\"
    
    server_node = None

    def handle_graph_request(self, method):
        if self.server_node:
            response_content = self.server_node.start_flow(self)
            
            if response_content:
                 self.send_response(200)
                 self.send_header('Content-type', 'text/html')
                 self.end_headers()
                 self.wfile.write(response_content.encode('utf-8'))
            elif self.path.startswith(settings.STATIC_URL):
                 super().do_GET()
            else:
                 self.send_error(404, "Page Not Found")
        else:
             self.send_error(500, "Server Node not configured")

    def do_GET(self):
        return self.handle_graph_request('GET')

    def do_POST(self):
        return self.handle_graph_request('POST')

    def do_PUT(self):
        return self.handle_graph_request('PUT')

    def do_PATCH(self):
        return self.handle_graph_request('PATCH')

    def do_DELETE(self):
        return self.handle_graph_request('DELETE')
"""

HTTP_REQUESTS_NODE_PY = """
import urllib.parse
from nodes.base_node import BaseNode

class HTTPRequestsNode(BaseNode):
    \"\"\"
    Node that transforms raw HTTP Handler into a Request Object.
    Connects Server -> URLNode.
    \"\"\"
    def __init__(self):
        super().__init__()

    def process(self, handler):
        \"\"\"
        Receives raw http.server handler.
        Parses request.
        Passes a 'request' wrapper to the next node.
        \"\"\"
        request = RequestWrapper(handler)
        return super().process(request)

class RequestWrapper:
    \"\"\"
    Simple wrapper to mimic the previous request object interface.
    
    Supported HTTP Methods and CRUD Mapping:
    Method | CRUD Action      | Idempotent?* | Description
    -------|------------------|--------------|---------------------------------------------
    GET    | Read             | Yes          | Requests data from a resource.
    POST   | Create           | No           | Submits data to be processed.
    PUT    | Update (Full)    | Yes          | Replaces the target resource with the request payload.
    PATCH  | Update (Partial) | No           | Applies partial modifications to a resource.
    DELETE | Delete           | Yes          | Deletes the specified resource.
    \"\"\"
    def __init__(self, handler):
        self.handler = handler
        parsed_url = urllib.parse.urlparse(handler.path)
        self.path = parsed_url.path
        self.headers = handler.headers
        self.method = handler.command
        
        # Parse query parameters from URL
        self.query_params = {k: v[0] if len(v) == 1 else v for k, v in urllib.parse.parse_qs(parsed_url.query).items()}
        
        self.params = {}
        self.context = {}
        self.body_bytes = b""
        
        # Parse body for methods that typically include a payload
        if self.method in ['POST', 'PUT', 'PATCH', 'DELETE']:
            self.parse_body()

    def parse_body(self):
        if 'Content-Length' in self.headers:
            content_length = int(self.headers['Content-Length'])
            self.body_bytes = self.handler.rfile.read(content_length)
            decoded_body = self.body_bytes.decode('utf-8')
            self.params = urllib.parse.parse_qs(decoded_body)

    def get_param(self, key, default=None):
        val_list = self.params.get(key)
        if val_list:
            return val_list[0]
        return default
"""

CONTEXT_NODE_PY = """
from nodes.base_node import BaseNode

class ContextNode(BaseNode):
    \"\"\"
    Executes a callable logic function to update the request context.
    Passes the request object to the next node.
    \"\"\"
    def __init__(self, context_func):
        super().__init__()
        self.context_func = context_func

    def process(self, request):
        \"\"\"
        Executes logic, merges result into request.context, and passes request forward.
        \"\"\"
        result = self.context_func(request)
        
        if isinstance(result, dict):
            request.context.update(result)
        
        return super().process(request)
"""

LOGIC_NODE_PY = """
from nodes.base_node import BaseNode
import sys

class LogicNode(BaseNode):
    \"\"\"
    Executes a callable logic function.
    \"\"\"
    def __init__(self, logic_func):
        super().__init__()
        self.logic_func = logic_func

    def process(self, request):
        \"\"\"
        Executes business logic.
        Expects 'request' object.
        Updates request.context and passes 'request' to the next node.
        \"\"\"
        result = self.logic_func(request)
        
        if isinstance(result, dict):
             request.context.update(result)
        
        return super().process(request)
"""

TEMPLATE_NODE_PY = """
import os
import sys
import settings
from nodes.base_node import BaseNode

class RenderNode(BaseNode):
    \"\"\"
    Handles template rendering (The 'Face' of the application).
    \"\"\"
    def __init__(self, template_name):
        super().__init__()
        self.template_name = template_name

    PYSCRIPT_HEADER = '''
    <link rel="stylesheet" href="https://pyscript.net/releases/2024.1.1/core.css" />
    <script type="module" src="https://pyscript.net/releases/2024.1.1/core.js"></script>
    '''

    def process(self, request):
        \"\"\"
        Receives request from the previous node, uses request.context, renders template, and returns HTML.
        \"\"\"
        context = getattr(request, 'context', request if isinstance(request, dict) else {})
        return self.render(self.template_name, context)

    @staticmethod
    def render(template_name, context=None):
        \"\"\"
        Reads an HTML file from settings.TEMPLATES_DIR, replaces placeholders, and returns content.
        \"\"\"
        if context is None:
            context = {}
        
        if not isinstance(context, dict):
             if context is None: context = {}
             else: context = {'data': context}

        context['pyscript_header'] = RenderNode.PYSCRIPT_HEADER

        template_path = os.path.join(settings.TEMPLATES_DIR, template_name)
        
        try:
            with open(template_path, 'r', encoding='utf-8') as f:
                content = f.read()

            for key, value in context.items():
                if isinstance(value, str):
                    content = content.replace(f"{{{key}}}", value)
            
            return content
            
        except FileNotFoundError:
            return f"<h1>Template {template_name} not found</h1>"
"""

URL_NODE_PY = """
from nodes.base_node import BaseNode

class URLNode(BaseNode):
    \"\"\"
    Represents a single route in the application (Routing Node).
    Checks if the request path matches.
    \"\"\"
    def __init__(self, path):
        super().__init__()
        self.path = path

    def process(self, request):
        \"\"\"
        Routing Logic:
        If match: Passes request to the next node (Logic).
        If no match: Returns None.
        \"\"\"
        # Standardize paths to single leading slash for comparison
        req_path = request.path if request.path.startswith('/') else '/' + request.path
        config_path = self.path if self.path.startswith('/') else '/' + self.path
        
        # Remove trailing slashes for identical matching unless root
        req_path_clean = req_path.rstrip('/') if req_path != '/' else '/'
        config_path_clean = config_path.rstrip('/') if config_path != '/' else '/'

        if req_path_clean == config_path_clean:
            return super().process(request)
        return None
"""

ROUTE_NODE_PY = """
from nodes.base_node import BaseNode

class RouterNode(BaseNode):
    \"\"\"
    Router Node that manages multiple route branches.
    It iterates through a list of route chains and executes the first one that matches.
    \"\"\"
    def __init__(self, routes):
        super().__init__()
        self.routes = routes

    def process(self, request):
        for route in self.routes:
            # route is expected to be a URLNode (start of a chain)
            result = route.process(request)
            if result is not None:
                return result
        return None
"""

DB_PY = """
import sqlite3
import os
import settings
from contextlib import contextmanager

class Database:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Database, cls).__new__(cls)
            cls._instance.db_path = os.path.join(settings.BASE_DIR, 'db.sqlite3')
            cls._instance.conn = None 
        return cls._instance

    def get_connection(self):
        \"\"\"Returns a new connection.\"\"\"
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.execute("PRAGMA foreign_keys = ON;") # Enable Foreign Keys
        return conn

    def execute(self, query, params=()):
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            conn.commit()
            return cursor
        except Exception as e:
            print(f"Database Error: {e}")
            raise e
        finally:
            conn.close()

    def executemany(self, query, params_list):
        \"\"\"Bulk insert/update optimization.\"\"\"
        conn = self.get_connection()
        try:
            with conn:
                conn.executemany(query, params_list)
        except Exception as e:
            print(f"Database Error (Bulk): {e}")
            raise e
        finally:
            conn.close()

    def executescript(self, script):
        \"\"\"Run a raw SQL script (good for migrations/triggers).\"\"\"
        conn = self.get_connection()
        try:
            with conn:
                conn.executescript(script)
        except Exception as e:
            print(f"Database Error (Script): {e}")
            raise e
        finally:
            conn.close()

    def fetchall(self, query, params=()):
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        except Exception as e:
            print(f"Database Error: {e}")
            return []
        finally:
            conn.close()
            
    def register_function(self, conn, name, num_params, func):
        conn.create_function(name, num_params, func)

    @contextmanager
    def transaction(self):
        conn = self.get_connection()
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            print(f"Transaction Rolled Back: {e}")
            raise e
        finally:
            conn.close()

    def setup_tables(self):
        create_schema = '''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_premium BOOLEAN DEFAULT 0
        );
        '''
        self.executescript(create_schema)
        create_trigger = '''
        CREATE TRIGGER IF NOT EXISTS validate_email_suffix
        BEFORE INSERT ON users
        BEGIN
            SELECT
            CASE
                WHEN NEW.email NOT LIKE '%@%' THEN
                RAISE (ABORT, 'Invalid email address')
            END;
        END;
        '''
        self.executescript(create_trigger)

    def create_table(self, table_name, columns_def):
        query = f"CREATE TABLE IF NOT EXISTS {table_name} ({columns_def});"
        self.execute(query)

    def alter_table(self, table_name, operation, details):
        if operation.upper() == 'ADD':
            query = f"ALTER TABLE {table_name} ADD {details};"
        elif operation.upper() == 'RENAME':
             query = f"ALTER TABLE {table_name} RENAME TO {details};"
        else:
            raise ValueError(f"Unsupported ALTER operation: {operation}")
        self.execute(query)

    def drop_table(self, table_name):
        query = f"DROP TABLE IF EXISTS {table_name};"
        self.execute(query)

    def create_view(self, view_name, select_query):
        query = f"CREATE VIEW IF NOT EXISTS {view_name} AS {select_query};"
        self.execute(query)

    def drop_view(self, view_name):
        query = f"DROP VIEW IF EXISTS {view_name};"
        self.execute(query)

    def create_index(self, index_name, table_name, columns, unique=False):
        unique_clause = "UNIQUE" if unique else ""
        query = f"CREATE {unique_clause} INDEX IF NOT EXISTS {index_name} ON {table_name} ({columns});"
        self.execute(query)
"""

MODEL_NODE_PY = """
from nodes.base_node import BaseNode
from core.db import Database

class ModelNode(BaseNode):
    \"\"\"
    Model Component of MVC.
    Interacts with the Database.
    \"\"\"
    def __init__(self, query, params_mapping=None, context_key='data', is_write=False):
        super().__init__()
        self.query = query
        self.params_mapping = params_mapping or []
        self.context_key = context_key
        self.is_write = is_write
        self.db = Database()

    def process(self, request):
        query_params = []
        is_bulk = False

        if self.params_mapping:
            first_key = self.params_mapping[0]
            val = request.context.get(first_key)
            
            if len(self.params_mapping) == 1 and isinstance(val, list):
                query_params = val
                is_bulk = True
            else:
                for key in self.params_mapping:
                    val = request.get_param(key)
                    if val is None:
                        val = request.context.get(key)
                    query_params.append(val)
        
        if self.is_write:
            try:
                if is_bulk:
                     self.db.executemany(self.query, query_params)
                     request.context[f'{self.context_key}_count'] = len(query_params)
                else:
                    self.db.execute(self.query, tuple(query_params))
                request.context[f'{self.context_key}_success'] = True
            except Exception as e:
                request.context['error'] = str(e)
        else:
            results = self.db.fetchall(self.query, tuple(query_params))
            request.context[self.context_key] = results
            
        return super().process(request)
"""

SECURITY_PY = """
from nodes.base_node import BaseNode
import time
import settings
import secrets

class RateLimitNode(BaseNode):
    \"\"\"
    Blocks IPs that exceed request limits.
    Config: SECURITY['RATE_LIMIT_MAX'] requests per SECURITY['RATE_LIMIT_WINDOW'] seconds.
    \"\"\"
    def __init__(self):
        super().__init__()
        self.ip_registry = {}

    def process(self, request):
        if not settings.SECURITY.get('RATE_LIMIT_ENABLED', True):
            return super().process(request)

        client_ip = request.handler.client_address[0]
        now = time.time()
        window = settings.SECURITY.get('RATE_LIMIT_WINDOW', 10)
        limit = settings.SECURITY.get('RATE_LIMIT_MAX', 10)
        history = self.ip_registry.get(client_ip, [])
        history = [t for t in history if t > now - window]
        
        if len(history) >= limit:
            print(f"⚠️ [Security] Rate Limit Exceeded for {client_ip}")
            return "<h1>429 Too Many Requests</h1><p>Please wait before trying again.</p>"
        
        history.append(now)
        self.ip_registry[client_ip] = history
        return super().process(request)

class CSRFNode(BaseNode):
    \"\"\"
    Protects against Cross-Site Request Forgery.
    \"\"\"
    def process(self, request):
        if not settings.SECURITY.get('CSRF_ENABLED', True):
            return super().process(request)
        
        csrf_token = "secure-token-123"
        
        if request.method == "POST":
            submitted_token = request.get_param('csrf_token')
            if submitted_token != csrf_token:
                 print(f"⚠️ [Security] CSRF Mismatch: Expected {csrf_token}, Got {submitted_token}")
                 return "<h1>403 Forbidden</h1><p>CSRF Validation Failed.</p>"
        
        request.context['csrf_token'] = csrf_token
        return super().process(request)

class AntiBotNode(BaseNode):
    \"\"\"
    Blocks Basic Bots and Scrapers.
    \"\"\"
    def process(self, request):
        if not settings.SECURITY.get('ANTI_SCRAPING_ENABLED', True):
            return super().process(request)

        user_agent = request.headers.get('User-Agent', '').lower()
        bot_keywords = ['curl', 'wget', 'python-requests', 'scrapy', 'bot', 'spider', 'crawler']
        if any(keyword in user_agent for keyword in bot_keywords):
             print(f"⚠️ [Security] Bot Detected: {user_agent}")
             return "<h1>403 Forbidden</h1><p>No Bots Allowed.</p>"

        return super().process(request)

class ScreenProtectionNode(BaseNode):
    \"\"\"
    Injects "Computer Vision Blocking" scripts and styles.
    Prevents selection, right-click, and overlays on blur.
    \"\"\"
    PROTECTION_SCRIPT = \"\"\"
    <style>
        body {
            user-select: none; 
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        }
        #protection-overlay {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: black;
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }
    </style>
    <div id="protection-overlay"><h1>Protected Content</h1></div>
    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
        document.addEventListener('keyup', (e) => {
            if (e.key == 'PrintScreen') {
                alert("Screenshots are disabled!");
                document.getElementById('protection-overlay').style.display = 'flex';
                setTimeout(() => { document.getElementById('protection-overlay').style.display = 'none'; }, 2000);
            }
        });
        window.addEventListener('blur', () => {
             document.getElementById('protection-overlay').style.display = 'flex';
        });
        window.addEventListener('focus', () => {
             document.getElementById('protection-overlay').style.display = 'none';
        });
    </script>
    \"\"\"

    def process(self, request):
        if not settings.SECURITY.get('SCREEN_PROTECTION_ENABLED', True):
            return super().process(request)
        
        response_content = super().process(request)
        
        if isinstance(response_content, str) and "</body>" in response_content:
            return response_content.replace("</body>", self.PROTECTION_SCRIPT + "</body>")
            
        return response_content
"""

LOGGER_PY = """
from nodes.base_node import BaseNode
import os
import datetime
import settings

class ActionLoggerNode(BaseNode):
    \"\"\"
    Logs every request to a file named after the Client IP.
    Location: core/logs/{ip}.txt
    \"\"\"
    def __init__(self):
        super().__init__()
        self.log_dir = os.path.join(settings.BASE_DIR, 'core', 'logs')
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

    def process(self, request):
        if not settings.LOGGING.get('ENABLED', True):
            return super().process(request)

        try:
            client_ip = request.handler.client_address[0]
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            method = request.method
            path = request.path
            user_agent = request.headers.get('User-Agent', 'Unknown')
            log_entry = f"[{timestamp}] {method} {path} | UA: {user_agent}\\n"
            log_file = os.path.join(self.log_dir, f"{client_ip}.txt")
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(log_entry)
        except Exception as e:
            print(f"Logger Error: {e}")

        return super().process(request)
"""

TEMPLATE_USERS_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Manager (MVC Demo)</title>
    <link rel="stylesheet" href="/static/style.css">
    <style>
        .user-list { text-align: left; margin-top: 20px; }
        .user-item { padding: 10px; border-bottom: 1px solid rgba(255,255,255,0.1); display: flex; justify-content: space-between; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>User Manager</h1>
            <p class="subtitle">MVC Pattern Demonstration</p>
            <form method="POST" action="/add_user">
                <input type="hidden" name="csrf_token" value="{csrf_token}">
                <div class="input-group">
                    <input type="text" name="name" placeholder="Name" required>
                </div>
                <div class="input-group">
                    <input type="email" name="email" placeholder="Email (Optional)">
                </div>
                <button type="submit">Add User</button>
            </form>
             <div class="user-list">
                <h3>Existing Users</h3>
                {user_list_html}
            </div>
            <div style="margin-top: 20px;">
                <a href="/" style="color: var(--primary);">Back to Home</a>
            </div>
        </div>
    </div>
</body>
</html>
"""

STATIC_LOGIC_PY = """
def check_odd_even(number):
    if number % 2 == 0:
        return "Even"
    else:
        return "Odd"

def weather_logic(request):
    return {
        'weather_widget': '''
        <div class="widget weather" style="margin-top: 20px; padding: 10px; background: #e0f7fa; border-radius: 8px;">
            <h3>☀️ Weather</h3>
            <p>It's always sunny in Python Land!</p>
        </div>
        '''
    }

def time_logic(request):
    import datetime
    now = datetime.datetime.now().strftime("%H:%M:%S")
    return {
        'time_widget': f'''
        <div class="widget time" style="margin-top: 10px; padding: 10px; background: #f3e5f5; border-radius: 8px;">
            <h3>⏰ Current Time</h3>
            <p>{now}</p>
        </div>
        '''
    }
"""

STATIC_STYLE_CSS = """
:root {
    --bg-color: #0f172a;
    --card-bg: rgba(30, 41, 59, 0.7);
    --primary: #3b82f6;
    --primary-hover: #2563eb;
    --text-main: #f8fafc;
    --text-sub: #94a3b8;
    --border: rgba(255, 255, 255, 0.1);
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
}

body {
    background-color: var(--bg-color);
    color: var(--text-main);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background-image: radial-gradient(circle at 50% 50%, #1e293b 0%, #0f172a 100%);
}

.container { width: 100%; max-width: 400px; padding: 20px; }

.card {
    background: var(--card-bg);
    border: 1px solid var(--border);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 2rem;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    text-align: center;
    animation: fadeIn 0.5s ease-out;
}

h1 {
    font-size: 2rem;
    margin-bottom: 0.5rem;
    background: linear-gradient(to right, #60a5fa, #a78bfa);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.subtitle { color: var(--text-sub); margin-bottom: 2rem; }
.input-group { margin-bottom: 1.5rem; }

input {
    width: 100%;
    padding: 1rem;
    border-radius: 12px;
    border: 1px solid var(--border);
    background: rgba(15, 23, 42, 0.5);
    color: white;
    font-size: 1.1rem;
    transition: border-color 0.3s, box-shadow 0.3s;
}

input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
}

button {
    width: 100%;
    padding: 1rem;
    border: none;
    border-radius: 12px;
    background: var(--primary);
    color: white;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.1s, background-color 0.3s;
}

button:hover { background-color: var(--primary-hover); }
button:active { transform: scale(0.98); }

.result {
    margin-top: 2rem;
    padding: 1rem;
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid var(--border);
    animation: slideUp 0.3s ease-out;
}

.result.Even { border-color: #34d399; color: #34d399; }
.result.Odd { border-color: #f472b6; color: #f472b6; }

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes slideUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}
"""

TEMPLATE_INDEX_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Odd or Even?</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    {result_text}
    <div class="container">
        {r1}
        <div class="card">
            <h1>Odd or Even?</h1>
            <p class="subtitle">Enter a number to find out.</p>
            <form method="POST" action="/">
                <input type="hidden" name="csrf_token" value="{csrf_token}">
                <div class="input-group">
                    <input type="number" name="number" placeholder="e.g., 42" required>
                </div>
                <button type="submit">Check Number</button>
            </form>
            {result_section}
            <div class="widgets-area">
                {weather_widget}
                {time_widget}
            </div>
        </div>
    </div>
</body>
</html>
"""

MAIN_PY = """import socketserver
import sys
import os
import settings
from nodes.server_node import FrameworkHandler, ServerNode
from nodes.base_node import BaseNode
from nodes.http_requests_node import HTTPRequestsNode
from nodes.url_node import URLNode
from nodes.logic_node import LogicNode
from nodes.context_node import ContextNode
from nodes.template_node import RenderNode
from nodes.route_node import RouterNode
from nodes.model_node import ModelNode
from core.db import Database
from static.logic import check_odd_even, weather_logic, time_logic
from plugins.security import RateLimitNode, CSRFNode, AntiBotNode, ScreenProtectionNode
from plugins.logger import ActionLoggerNode

# --- Initialize Database ---
db = Database()
db.setup_tables()

try:
    db.create_table("projects", "id INTEGER PRIMARY KEY, user_id INTEGER, title TEXT, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE")
    db.create_index("idx_user_email", "users", "email", unique=True)
    db.create_view("v_premium_users", "SELECT * FROM users WHERE is_premium = 1")
    print("Database Schema Updated.")
except Exception as e:
    print(f"Schema Init Warning: {e}")


def index_logic(request):
    if request.method == 'POST':
        number = request.get_param('number')
        if number and number.isdigit():
            res = check_odd_even(int(number))
            return {'result_section': f'<div class="result {res}">{number} is {res}</div>'}
    return {'result_section': ''}

def format_user_list(request):
    users = request.context.get('users', [])
    html = ""
    if not users:
        html = "<p>No users found.</p>"
    else:
        for user in users:
            premium = "⭐" if user.get('is_premium') else ""
            html += f'<div class="user-item"><span>{user["name"]} {premium}</span> <span style="color: #666;">{user["email"]}</span></div>'
    return {'user_list_html': html}

server_node = ServerNode(port=settings.PORT)
http_request_node = HTTPRequestsNode()

url_index = URLNode('/')
logic_index = LogicNode(index_logic)
logic_r1 = LogicNode(lambda r: {'r1': ''}) 
node_weather = LogicNode(weather_logic)
node_time = LogicNode(time_logic)
render_index = RenderNode('index.html')
url_index.connect(logic_index).connect(logic_r1).connect(node_weather).connect(node_time).connect(render_index)

url_users = URLNode('/users')
model_fetch_users = ModelNode(query="SELECT * FROM users ORDER BY id DESC", context_key='users')
logic_format_users = LogicNode(format_user_list)
render_users = RenderNode('users.html')
url_users.connect(model_fetch_users).connect(logic_format_users).connect(render_users)

url_add_user = URLNode('/add_user')
model_add_user = ModelNode(query="INSERT INTO users (name, email) VALUES (?, ?)", params_mapping=['name', 'email'], is_write=True)
model_fetch_users_post = ModelNode(query="SELECT * FROM users ORDER BY id DESC", context_key='users')
logic_format_users_post = LogicNode(format_user_list)
render_users_post = RenderNode('users.html')
url_add_user.connect(model_add_user).connect(model_fetch_users_post).connect(logic_format_users_post).connect(render_users_post)

router_node = RouterNode([url_index, url_users, url_add_user])

action_logger = ActionLoggerNode()
security_antibot = AntiBotNode()
security_ratelimit = RateLimitNode()
security_csrf = CSRFNode()
security_screen = ScreenProtectionNode()

server_node.connect(http_request_node).connect(action_logger).connect(security_antibot).connect(security_ratelimit).connect(security_csrf).connect(security_screen).connect(router_node)

if __name__ == "__main__":
    PORT = settings.PORT
    FrameworkHandler.server_node = server_node
    
    print(f"Starting MVC Framework Server at http://localhost:{PORT}")
    print("To launch the visual Node Editor, run: python node_editor/node_backend.py")
    
    socketserver.TCPServer.allow_reuse_address = True
    try:
        with socketserver.TCPServer(("", PORT), FrameworkHandler) as httpd:
            httpd.serve_forever()
    except KeyboardInterrupt:
        httpd.server_close()
"""

# --- Node Editor GUI Files ---

WEBNODE_HTML = open(os.path.join(os.path.dirname(__file__), '_editor_files', 'index.html'), 'r', encoding='utf-8').read() if os.path.exists(os.path.join(os.path.dirname(__file__), '_editor_files', 'index.html')) else ""
WEBNODE_CSS = open(os.path.join(os.path.dirname(__file__), '_editor_files', 'styles.css'), 'r', encoding='utf-8').read() if os.path.exists(os.path.join(os.path.dirname(__file__), '_editor_files', 'styles.css')) else ""
WEBNODE_JS = open(os.path.join(os.path.dirname(__file__), '_editor_files', 'canvas.js'), 'r', encoding='utf-8').read() if os.path.exists(os.path.join(os.path.dirname(__file__), '_editor_files', 'canvas.js')) else ""
WEBNODE_BACKEND_PY = open(os.path.join(os.path.dirname(__file__), '_editor_files', 'node_backend.py'), 'r', encoding='utf-8').read() if os.path.exists(os.path.join(os.path.dirname(__file__), '_editor_files', 'node_backend.py')) else ""

# --- Creation Logic (CLI Version) ---

def create_project(project_name):
    base_path = os.path.join(os.getcwd(), project_name)
    
    if os.path.exists(base_path):
        print(f"Error: Directory '{project_name}' already exists.")
        sys.exit(1)
        
    print(f"Initializing Framework Project '{project_name}'...")
    create_directory(base_path)

    create_directory(os.path.join(base_path, "nodes"))
    create_directory(os.path.join(base_path, "core"))
    create_directory(os.path.join(base_path, "static"))
    create_directory(os.path.join(base_path, "templates"))
    create_directory(os.path.join(base_path, "plugins"))
    create_directory(os.path.join(base_path, "node_editor"))

    write_file(os.path.join(base_path, "settings.py"), SETTINGS_PY)

    write_file(os.path.join(base_path, "plugins", "__init__.py"), "")
    write_file(os.path.join(base_path, "plugins", "security.py"), SECURITY_PY)
    write_file(os.path.join(base_path, "plugins", "logger.py"), LOGGER_PY)

    write_file(os.path.join(base_path, "nodes", "__init__.py"), "")
    write_file(os.path.join(base_path, "nodes", "base_node.py"), BASE_NODE_PY)
    write_file(os.path.join(base_path, "nodes", "server_node.py"), SERVER_NODE_PY)
    write_file(os.path.join(base_path, "nodes", "http_requests_node.py"), HTTP_REQUESTS_NODE_PY)
    write_file(os.path.join(base_path, "nodes", "context_node.py"), CONTEXT_NODE_PY)
    write_file(os.path.join(base_path, "nodes", "logic_node.py"), LOGIC_NODE_PY)
    write_file(os.path.join(base_path, "nodes", "template_node.py"), TEMPLATE_NODE_PY)
    write_file(os.path.join(base_path, "nodes", "url_node.py"), URL_NODE_PY)
    write_file(os.path.join(base_path, "nodes", "route_node.py"), ROUTE_NODE_PY)
    
    write_file(os.path.join(base_path, "core", "db.py"), DB_PY)
    write_file(os.path.join(base_path, "nodes", "model_node.py"), MODEL_NODE_PY)

    write_file(os.path.join(base_path, "static", "logic.py"), STATIC_LOGIC_PY)
    write_file(os.path.join(base_path, "static", "style.css"), STATIC_STYLE_CSS)
    write_file(os.path.join(base_path, "templates", "index.html"), TEMPLATE_INDEX_HTML)
    write_file(os.path.join(base_path, "templates", "users.html"), TEMPLATE_USERS_HTML)

    # Node Editor Files from bundled data
    _editor_src = os.path.join(os.path.dirname(__file__), '_editor_files')
    for fname in ['index.html', 'styles.css', 'canvas.js', 'node_backend.py']:
        src = os.path.join(_editor_src, fname)
        dst = os.path.join(base_path, 'node_editor', fname)
        if os.path.exists(src):
            with open(src, 'r', encoding='utf-8') as f:
                content = f.read()
            with open(dst, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"Created file: {dst}")

    write_file(os.path.join(base_path, "main.py"), MAIN_PY)

    secret_file = os.path.join(base_path, ".secret_key")
    key = secrets.token_urlsafe(50)
    with open(secret_file, 'w') as f:
        f.write(key)
    print("Generated new secret key.")

    print(f"\nProject '{project_name}' created successfully.")
    print(f"To start the server:  cd {project_name} && python main.py")
    print(f"To launch Node Editor: cd {project_name} && python node_editor/node_backend.py")

def main():
    parser = argparse.ArgumentParser(description="WebNode Framework CLI")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    startproject_parser = subparsers.add_parser('startproject', help='Create a new WebNode project')
    startproject_parser.add_argument('name', help='Name of the project directory')

    args = parser.parse_args()

    if args.command == 'startproject':
        create_project(args.name)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
